.. include:: ../README.rst
  :start-after:	installation-start-inclusion-marker-do-not-remove
  :end-before: installation-end-inclusion-marker-do-not-remove
